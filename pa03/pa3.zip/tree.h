#ifndef __TREE_H__
#define __TREE_H__

typedef struct _Tnode {
   char cutline;
   int label, w, h, x, y;
   struct _Tnode *left;
   struct _Tnode *right;
} Tnode;

void Print_Tree(Tnode *root);
//out_file1
Tnode *Tree_Load_From_File(char *in_file);
Tnode *Build_BST(FILE *fp);
int Preorder_Save_To_File(char *filename, Tnode *root, int activateXY);
void Preorder_BST(FILE *fp, Tnode *root, int activateXY);
//out_file2
Tnode *reRootLR_test(Tnode *root);
Tnode *reRootRL_test(Tnode *root);

Tnode *LR(Tnode *root);
Tnode *RL(Tnode *root);
Tnode *LL(Tnode *root);
Tnode *RR(Tnode *root);

Tnode *reRootAll(Tnode *root);
Tnode *reRootL(Tnode *root);
Tnode *reRootR(Tnode *root);

void Postorder_rebuild_BST(Tnode *root);

void Free_Tree(Tnode* node);

#endif